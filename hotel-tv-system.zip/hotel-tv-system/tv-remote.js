/**
 * TV Remote Navigation Library
 * Biblioteca JavaScript para criar interfaces web navegáveis por controle remoto de TV
 * @version 1.0.0
 * @license MIT
 */

(function(window) {
  'use strict';

  // ==================== UTILS ====================

  /**
   * Verifica se um elemento é focável
   */
  function isFocusable(element) {
    if (!element || element.hasAttribute('disabled') || element.hasAttribute('data-tv-disabled')) {
      return false;
    }

    const style = window.getComputedStyle(element);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
      return false;
    }

    return element.hasAttribute('data-tv-focusable');
  }

  /**
   * Obtém todos os elementos focáveis em um container
   */
  function getFocusableElements(container) {
    container = container || document.body;
    const elements = Array.from(container.querySelectorAll('[data-tv-focusable]'));
    return elements.filter(isFocusable);
  }

  /**
   * Obtém o índice de navegação de um elemento
   */
  function getNavigationIndex(element) {
    const index = element.getAttribute('data-tv-index');
    return index !== null ? parseInt(index, 10) : Infinity;
  }

  /**
   * Ordena elementos focáveis por índice de navegação
   */
  function sortByNavigationIndex(elements) {
    return elements.sort(function(a, b) {
      const indexA = getNavigationIndex(a);
      const indexB = getNavigationIndex(b);

      if (indexA === indexB) {
        return 0;
      }

      return indexA - indexB;
    });
  }

  /**
   * Obtém o grupo de navegação de um elemento
   */
  function getNavigationGroup(element) {
    return element.getAttribute('data-tv-group') || null;
  }

  /**
   * Filtra elementos pelo grupo de navegação
   */
  function filterByGroup(elements, group) {
    if (!group) return elements;
    return elements.filter(function(el) {
      return getNavigationGroup(el) === group;
    });
  }

  /**
   * Adiciona classe CSS a um elemento
   */
  function addClass(element, className) {
    if (element && className) {
      element.classList.add(className);
    }
  }

  /**
   * Remove classe CSS de um elemento
   */
  function removeClass(element, className) {
    if (element && className) {
      element.classList.remove(className);
    }
  }

  /**
   * Dispara um evento customizado em um elemento
   */
  function dispatchCustomEvent(element, eventName, detail) {
    detail = detail || {};
    const event = new CustomEvent(eventName, {
      bubbles: true,
      cancelable: true,
      detail: detail
    });
    return element.dispatchEvent(event);
  }

  /**
   * Verifica se um elemento está dentro do viewport
   */
  function isInViewport(element) {
    const rect = element.getBoundingClientRect();
    return (
      rect.top >= 0 &&
      rect.left >= 0 &&
      rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
      rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
  }

  /**
   * Rola a página para tornar um elemento visível
   */
  function scrollIntoViewIfNeeded(element, options) {
    options = options || {};
    if (!isInViewport(element)) {
      element.scrollIntoView({
        behavior: options.behavior || 'smooth',
        block: options.block || 'center',
        inline: options.inline || 'center'
      });
    }
  }

  // ==================== KEY MAPPER ====================

  const KEY_MAP = {
    // Navegação direcional
    'ArrowUp': 'up',
    'ArrowDown': 'down',
    'ArrowLeft': 'left',
    'ArrowRight': 'right',

    // Confirmação
    'Enter': 'ok',
    'Space': 'ok',

    // Botões auxiliares
    'Backspace': 'back',
    'Escape': 'back',
    'Home': 'home',
    'ContextMenu': 'menu',

    // Botões de mídia
    'MediaPlayPause': 'play-pause',
    'MediaPlay': 'play',
    'MediaPause': 'pause',
    'MediaStop': 'stop',
    'MediaTrackNext': 'next',
    'MediaTrackPrevious': 'previous',
    'MediaRewind': 'rewind',
    'MediaFastForward': 'fast-forward',

    // Controle de volume
    'AudioVolumeUp': 'volume-up',
    'AudioVolumeDown': 'volume-down',
    'AudioVolumeMute': 'mute',

    // Botões numéricos
    'Digit0': '0',
    'Digit1': '1',
    'Digit2': '2',
    'Digit3': '3',
    'Digit4': '4',
    'Digit5': '5',
    'Digit6': '6',
    'Digit7': '7',
    'Digit8': '8',
    'Digit9': '9',
    'Numpad0': '0',
    'Numpad1': '1',
    'Numpad2': '2',
    'Numpad3': '3',
    'Numpad4': '4',
    'Numpad5': '5',
    'Numpad6': '6',
    'Numpad7': '7',
    'Numpad8': '8',
    'Numpad9': '9',

    // Cores
    'ColorF0Red': 'red',
    'ColorF1Green': 'green',
    'ColorF2Yellow': 'yellow',
    'ColorF3Blue': 'blue'
  };

  /**
   * Classe responsável por mapear eventos de teclado para ações do controle remoto
   */
  function KeyMapper(customMap) {
    customMap = customMap || {};
    this.keyMap = Object.assign({}, KEY_MAP, customMap);
  }

  KeyMapper.prototype.mapKey = function(event) {
    const code = event.code;
    const key = event.key;

    if (this.keyMap[code]) {
      return this.keyMap[code];
    }

    if (this.keyMap[key]) {
      return this.keyMap[key];
    }

    return null;
  };

  KeyMapper.prototype.addMapping = function(keyCode, action) {
    this.keyMap[keyCode] = action;
  };

  KeyMapper.prototype.removeMapping = function(keyCode) {
    delete this.keyMap[keyCode];
  };

  KeyMapper.prototype.isDirectional = function(action) {
    return ['up', 'down', 'left', 'right'].indexOf(action) !== -1;
  };

  KeyMapper.prototype.isNumeric = function(action) {
    return /^[0-9]$/.test(action);
  };

  KeyMapper.prototype.isMedia = function(action) {
    return ['play-pause', 'play', 'pause', 'stop', 'next', 'previous', 'rewind', 'fast-forward'].indexOf(action) !== -1;
  };

  // ==================== FOCUS MANAGER ====================

  /**
   * Classe responsável por gerenciar o foco entre elementos navegáveis
   */
  function FocusManager(options) {
    options = options || {};
    this.focusClass = options.focusClass || 'tv-focused';
    this.container = options.container || document.body;
    this.wrapAround = options.wrapAround !== false;
    this.autoScroll = options.autoScroll !== false;
    this.onFocusChange = options.onFocusChange || null;

    this.currentElement = null;
    this.currentGroup = null;
    this.focusableElements = [];

    this.updateFocusableElements();
  }

  FocusManager.prototype.updateFocusableElements = function() {
    this.focusableElements = sortByNavigationIndex(
      getFocusableElements(this.container)
    );
  };

  FocusManager.prototype.getCurrentGroupElements = function() {
    if (this.currentGroup) {
      return filterByGroup(this.focusableElements, this.currentGroup);
    }
    return this.focusableElements;
  };

  FocusManager.prototype.focus = function(elementOrIndex) {
    this.updateFocusableElements();

    var element;
    if (typeof elementOrIndex === 'number') {
      const elements = this.getCurrentGroupElements();
      element = elements[elementOrIndex];
    } else {
      element = elementOrIndex;
    }

    if (!element || this.focusableElements.indexOf(element) === -1) {
      return false;
    }

    if (this.currentElement) {
      removeClass(this.currentElement, this.focusClass);
      dispatchCustomEvent(this.currentElement, 'tv:blur', {
        element: this.currentElement
      });
    }

    this.currentElement = element;
    this.currentGroup = getNavigationGroup(element);
    addClass(this.currentElement, this.focusClass);

    if (this.autoScroll) {
      scrollIntoViewIfNeeded(this.currentElement);
    }

    dispatchCustomEvent(this.currentElement, 'tv:focus', {
      element: this.currentElement
    });

    if (this.onFocusChange) {
      this.onFocusChange(this.currentElement);
    }

    return true;
  };

  FocusManager.prototype.focusFirst = function() {
    const elements = this.getCurrentGroupElements();
    return elements.length > 0 ? this.focus(elements[0]) : false;
  };

  FocusManager.prototype.focusLast = function() {
    const elements = this.getCurrentGroupElements();
    return elements.length > 0 ? this.focus(elements[elements.length - 1]) : false;
  };

  FocusManager.prototype.focusNext = function() {
    const elements = this.getCurrentGroupElements();
    if (elements.length === 0) return false;

    if (!this.currentElement) {
      return this.focusFirst();
    }

    const currentIndex = elements.indexOf(this.currentElement);
    if (currentIndex === -1) {
      return this.focusFirst();
    }

    const nextIndex = currentIndex + 1;

    if (nextIndex >= elements.length) {
      return this.wrapAround ? this.focus(elements[0]) : false;
    }

    return this.focus(elements[nextIndex]);
  };

  FocusManager.prototype.focusPrevious = function() {
    const elements = this.getCurrentGroupElements();
    if (elements.length === 0) return false;

    if (!this.currentElement) {
      return this.focusLast();
    }

    const currentIndex = elements.indexOf(this.currentElement);
    if (currentIndex === -1) {
      return this.focusLast();
    }

    const prevIndex = currentIndex - 1;

    if (prevIndex < 0) {
      return this.wrapAround ? this.focus(elements[elements.length - 1]) : false;
    }

    return this.focus(elements[prevIndex]);
  };

  FocusManager.prototype.focusUp = function() {
    if (!this.currentElement) return this.focusPrevious();

    const customTarget = this.currentElement.getAttribute('data-tv-up');
    if (customTarget) {
      const targetElement = document.querySelector(customTarget);
      if (targetElement) {
        return this.focus(targetElement);
      }
    }

    return this.focusPrevious();
  };

  FocusManager.prototype.focusDown = function() {
    if (!this.currentElement) return this.focusNext();

    const customTarget = this.currentElement.getAttribute('data-tv-down');
    if (customTarget) {
      const targetElement = document.querySelector(customTarget);
      if (targetElement) {
        return this.focus(targetElement);
      }
    }

    return this.focusNext();
  };

  FocusManager.prototype.focusLeft = function() {
    if (!this.currentElement) return this.focusPrevious();

    const customTarget = this.currentElement.getAttribute('data-tv-left');
    if (customTarget) {
      const targetElement = document.querySelector(customTarget);
      if (targetElement) {
        return this.focus(targetElement);
      }
    }

    return this.focusPrevious();
  };

  FocusManager.prototype.focusRight = function() {
    if (!this.currentElement) return this.focusNext();

    const customTarget = this.currentElement.getAttribute('data-tv-right');
    if (customTarget) {
      const targetElement = document.querySelector(customTarget);
      if (targetElement) {
        return this.focus(targetElement);
      }
    }

    return this.focusNext();
  };

  FocusManager.prototype.changeGroup = function(groupName) {
    this.currentGroup = groupName;
    return this.focusFirst();
  };

  FocusManager.prototype.getCurrentElement = function() {
    return this.currentElement;
  };

  FocusManager.prototype.clearFocus = function() {
    if (this.currentElement) {
      removeClass(this.currentElement, this.focusClass);
      dispatchCustomEvent(this.currentElement, 'tv:blur', {
        element: this.currentElement
      });
      this.currentElement = null;
    }
  };

  FocusManager.prototype.destroy = function() {
    this.clearFocus();
    this.focusableElements = [];
    this.container = null;
    this.onFocusChange = null;
  };

  // ==================== TV REMOTE ====================

  /**
   * Classe principal da biblioteca TV Remote Navigation
   */
  function TVRemote(options) {
    options = options || {};
    this.options = {
      container: options.container || document.body,
      focusClass: options.focusClass || 'tv-focused',
      wrapAround: options.wrapAround !== false,
      autoScroll: options.autoScroll !== false,
      autoInit: options.autoInit !== false,
      preventDefaultKeys: options.preventDefaultKeys !== false,
      customKeyMap: options.customKeyMap || {},
      callbacks: options.callbacks || {}
    };

    this.keyMapper = new KeyMapper(this.options.customKeyMap);
    this.focusManager = new FocusManager({
      container: this.options.container,
      focusClass: this.options.focusClass,
      wrapAround: this.options.wrapAround,
      autoScroll: this.options.autoScroll,
      onFocusChange: this.options.callbacks.onFocusChange
    });

    this.eventListeners = new Map();
    this.keyboardHandler = null;
    this.initialized = false;

    if (this.options.autoInit) {
      this.init();
    }
  }

  TVRemote.prototype.init = function() {
    if (this.initialized) {
      console.warn('TVRemote já foi inicializado');
      return;
    }

    this.keyboardHandler = this.handleKeyboardEvent.bind(this);
    document.addEventListener('keydown', this.keyboardHandler);

    this.focusManager.focusFirst();

    this.initialized = true;

    dispatchCustomEvent(document, 'tv:init', {
      tvRemote: this
    });

    if (this.options.callbacks.onInit) {
      this.options.callbacks.onInit(this);
    }
  };

  TVRemote.prototype.handleKeyboardEvent = function(event) {
    const action = this.keyMapper.mapKey(event);

    if (!action) {
      return;
    }

    if (this.options.preventDefaultKeys) {
      event.preventDefault();
      event.stopPropagation();
    }

    const currentElement = this.focusManager.getCurrentElement();
    if (currentElement) {
      const allowed = dispatchCustomEvent(currentElement, 'tv:keydown', {
        action: action,
        originalEvent: event,
        element: currentElement
      });

      if (!allowed) {
        return;
      }
    }

    this.executeAction(action, event);
  };

  TVRemote.prototype.executeAction = function(action, event) {
    const currentElement = this.focusManager.getCurrentElement();

    if (this.keyMapper.isDirectional(action)) {
      const methods = {
        'up': 'focusUp',
        'down': 'focusDown',
        'left': 'focusLeft',
        'right': 'focusRight'
      };
      this.focusManager[methods[action]]();
      return;
    }

    if (action === 'ok') {
      if (currentElement) {
        dispatchCustomEvent(currentElement, 'tv:select', {
          element: currentElement,
          originalEvent: event
        });

        currentElement.click();
      }
      return;
    }

    if (action === 'back') {
      dispatchCustomEvent(document, 'tv:back', {
        element: currentElement,
        originalEvent: event
      });

      if (this.options.callbacks.onBack) {
        this.options.callbacks.onBack(currentElement, event);
      }
      return;
    }

    if (action === 'home') {
      dispatchCustomEvent(document, 'tv:home', {
        element: currentElement,
        originalEvent: event
      });

      if (this.options.callbacks.onHome) {
        this.options.callbacks.onHome(currentElement, event);
      }
      return;
    }

    if (action === 'menu') {
      dispatchCustomEvent(document, 'tv:menu', {
        element: currentElement,
        originalEvent: event
      });

      if (this.options.callbacks.onMenu) {
        this.options.callbacks.onMenu(currentElement, event);
      }
      return;
    }

    if (this.keyMapper.isMedia(action)) {
      dispatchCustomEvent(document, 'tv:media:' + action, {
        element: currentElement,
        originalEvent: event,
        action: action
      });

      if (this.options.callbacks.onMedia) {
        this.options.callbacks.onMedia(action, currentElement, event);
      }
      return;
    }

    if (this.keyMapper.isNumeric(action)) {
      dispatchCustomEvent(document, 'tv:numeric', {
        element: currentElement,
        originalEvent: event,
        number: action
      });

      if (this.options.callbacks.onNumeric) {
        this.options.callbacks.onNumeric(action, currentElement, event);
      }
      return;
    }

    dispatchCustomEvent(document, 'tv:action:' + action, {
      element: currentElement,
      originalEvent: event,
      action: action
    });
  };

  TVRemote.prototype.on = function(eventName, callback) {
    if (!this.eventListeners.has(eventName)) {
      this.eventListeners.set(eventName, []);
    }
    this.eventListeners.get(eventName).push(callback);

    document.addEventListener(eventName, callback);
  };

  TVRemote.prototype.off = function(eventName, callback) {
    if (this.eventListeners.has(eventName)) {
      const listeners = this.eventListeners.get(eventName);
      const index = listeners.indexOf(callback);
      if (index > -1) {
        listeners.splice(index, 1);
      }
    }
    document.removeEventListener(eventName, callback);
  };

  TVRemote.prototype.focus = function(elementOrSelector) {
    var element = elementOrSelector;
    if (typeof elementOrSelector === 'string') {
      element = document.querySelector(elementOrSelector);
    }
    return this.focusManager.focus(element);
  };

  TVRemote.prototype.refresh = function() {
    this.focusManager.updateFocusableElements();
  };

  TVRemote.prototype.getCurrentElement = function() {
    return this.focusManager.getCurrentElement();
  };

  TVRemote.prototype.changeGroup = function(groupName) {
    return this.focusManager.changeGroup(groupName);
  };

  TVRemote.prototype.addKeyMapping = function(keyCode, action) {
    this.keyMapper.addMapping(keyCode, action);
  };

  TVRemote.prototype.removeKeyMapping = function(keyCode) {
    this.keyMapper.removeMapping(keyCode);
  };

  TVRemote.prototype.destroy = function() {
    if (this.keyboardHandler) {
      document.removeEventListener('keydown', this.keyboardHandler);
      this.keyboardHandler = null;
    }

    var self = this;
    this.eventListeners.forEach(function(listeners, eventName) {
      listeners.forEach(function(callback) {
        document.removeEventListener(eventName, callback);
      });
    });
    this.eventListeners.clear();

    this.focusManager.destroy();

    this.initialized = false;

    dispatchCustomEvent(document, 'tv:destroy', {
      tvRemote: this
    });
  };

  // ==================== API PÚBLICA ====================

  var defaultInstance = null;

  /**
   * Inicializa a instância padrão da biblioteca
   */
  function init(options) {
    if (defaultInstance) {
      console.warn('TVRemote já possui uma instância padrão. Use destroy() antes de criar uma nova.');
      return defaultInstance;
    }

    defaultInstance = new TVRemote(options);
    return defaultInstance;
  }

  /**
   * Obtém a instância padrão
   */
  function getInstance() {
    return defaultInstance;
  }

  /**
   * Destroi a instância padrão
   */
  function destroy() {
    if (defaultInstance) {
      defaultInstance.destroy();
      defaultInstance = null;
    }
  }

  // Expõe a API no objeto window
  window.TVRemote = {
    init: init,
    getInstance: getInstance,
    destroy: destroy,
    TVRemote: TVRemote
  };

})(window);
