# 📺 Hotel TV System

Sistema completo de interface de TV para hotéis com navegação por controle remoto e controle IoT integrado.

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Version](https://img.shields.io/badge/version-1.0.0-green.svg)

## ✨ Características

- 🎮 **Navegação por Controle Remoto** - Biblioteca TV Remote integrada
- 🏠 **6 Seções Principais** - Checkout, Billing, Controles IoT, Serviços, Informações e Apps
- 🔌 **Controle IoT** - Luz (intensidade ajustável) e Cortina (posição variável)
- 📱 **4 Apps de Streaming** - Netflix, Spotify, YouTube e Apple TV
- 📺 **Design para TV** - 1920x1080px otimizado para telas grandes
- ⌨️ **Navegação Intuitiva** - Setas direcionais + Enter/OK para selecionar
- ◀️ **Tecla Back/ESC** - Volta para tela principal
- 🎨 **Identidade Visual Consistente** - Gradientes e cores temáticas

## 🚀 Demo

```bash
# Clone o repositório
git clone https://github.com/seu-usuario/hotel-tv-system.git
cd hotel-tv-system

# Inicie um servidor local
python3 -m http.server 8080

# Abra no navegador
http://localhost:8080
```

## 📁 Estrutura do Projeto

```
hotel-tv-system/
├── index.html              # Página principal (Home)
├── info.html               # Informações do hotel
├── checkout.html           # Checkout do hóspede
├── billing.html            # Fatura/Conta
├── services.html           # Serviços disponíveis
├── iot-control.html        # Controle IoT (Luz e Cortina)
├── tv-remote.js            # Biblioteca de navegação
├── docs/
│   ├── ARCHITECTURE.md     # Arquitetura do sistema
│   └── FLUXO-VERIFICACAO.md # Checklist de testes
├── .gitignore
├── LICENSE
├── CONTRIBUTING.md
└── README.md
```

## 🎮 Como Usar

### Controles

| Tecla | Ação |
|-------|------|
| ↑ ↓ ← → | Navegar entre elementos |
| Enter / Space | Selecionar / OK |
| Backspace / ESC | Voltar |
| Home | Ir para início |

### Navegação

1. Use as **setas** do teclado ou controle remoto
2. **Enter** para selecionar um item
3. **ESC** para voltar à tela principal

## 🔧 Instalação

### Desenvolvimento Local

```bash
# Clone o repositório
git clone https://github.com/seu-usuario/hotel-tv-system.git
cd hotel-tv-system

# Opção 1: Python
python3 -m http.server 8080

# Opção 2: Node.js
npx http-server -p 8080

# Opção 3: PHP
php -S localhost:8080
```

### Deploy em Produção

**Servidor Web (Apache/Nginx):**
1. Faça upload dos arquivos para o servidor
2. Configure o virtual host
3. Acesse via Smart TV

**CDN:**
- Upload para S3/CloudFront
- Configure cache headers
- Distribua globalmente

## 🎨 Customização

### Nome do Hóspede e Quarto

Edite `index.html`:

```html
<div class="guest-name">Seu Nome</div>
<div class="number">512</div>
```

### Cores Temáticas

Edite o CSS de cada página:

```css
/* Checkout - Vermelho */
.nav-button.checkout { border-color: #ef5350; }

/* Billing - Azul */
.nav-button.billing { border-color: #42a5f5; }

/* IoT - Roxo */
.nav-button.iot { border-color: #ab47bc; }
```

### Integração IoT

Configure a função `sendIoTCommand()` em `iot-control.html`:

```javascript
function sendIoTCommand(device, params) {
    fetch('/api/iot/command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ room: '512', device, ...params })
    });
}
```

## 📚 Documentação

- 📖 [Arquitetura do Sistema](docs/ARCHITECTURE.md)
- ✅ [Checklist de Testes](docs/FLUXO-VERIFICACAO.md)
- 🤝 [Guia de Contribuição](CONTRIBUTING.md)

## 🛠️ Tecnologias

- **HTML5** - Estrutura
- **CSS3** - Estilos e animações
- **JavaScript (Vanilla)** - Lógica
- **Bootstrap 4** - Grid system
- **Font Awesome 5** - Ícones
- **TV Remote Library** - Navegação customizada

## 🌐 Compatibilidade

| Plataforma | Versão | Status |
|------------|--------|--------|
| LG webOS | 4.0+ | ✅ Testado |
| Samsung Tizen | 5.0+ | ✅ Testado |
| Android TV | 9.0+ | ✅ Testado |
| Fire TV | - | ✅ Testado |
| Chrome/Edge | 90+ | ✅ Testado |

## 🤝 Contribuindo

Contribuições são bem-vindas! Veja o [Guia de Contribuição](CONTRIBUTING.md).

1. Fork o projeto
2. Crie uma branch (`git checkout -b feature/MinhaFeature`)
3. Commit suas mudanças (`git commit -m 'feat: adiciona MinhaFeature'`)
4. Push para a branch (`git push origin feature/MinhaFeature`)
5. Abra um Pull Request

## 📝 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 👥 Autores

- **Murillo Fogaça** - [@Murilloxfogaca](https://github.com/Murilloxfogaca)

## 🙏 Agradecimentos

- Biblioteca TV Remote Navigation
- Comunidade de desenvolvedores de Smart TVs
- Contributors e testers

## 📞 Suporte

- 📧 Email: support@hotel-tv-system.com
- 🐛 Issues: [GitHub Issues](https://github.com/seu-usuario/hotel-tv-system/issues)
- 📖 Docs: [Documentation](docs/)

---

**Desenvolvido com ❤️ para Hospitality Tech** 🏨📺