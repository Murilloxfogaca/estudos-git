# 🤝 Guia de Contribuição

Obrigado por considerar contribuir com o Hotel TV System! 

## 📋 Como Contribuir

### 1. Fork o Projeto
```bash
# Clone seu fork
git clone https://github.com/seu-usuario/hotel-tv-system.git
cd hotel-tv-system
```

### 2. Crie uma Branch
```bash
# Para nova feature
git checkout -b feature/minha-feature

# Para correção de bug
git checkout -b fix/meu-bug
```

### 3. Faça suas Alterações

**Padrões de Código:**
- Use indentação de 4 espaços
- Comente código complexo
- Siga o padrão de nomenclatura existente
- Mantenha a consistência visual

**Commits:**
```bash
# Use mensagens descritivas
git commit -m "feat: adiciona controle de temperatura"
git commit -m "fix: corrige bug na navegação do slider"
git commit -m "docs: atualiza README com novas instruções"
```

**Padrão de Commit:**
- `feat:` - Nova funcionalidade
- `fix:` - Correção de bug
- `docs:` - Documentação
- `style:` - Formatação, CSS
- `refactor:` - Refatoração de código
- `test:` - Testes
- `chore:` - Manutenção

### 4. Teste suas Alterações

```bash
# Inicie servidor local
python3 -m http.server 8080

# Teste no navegador
open http://localhost:8080

# Verifique:
# - Navegação por teclado (setas, Enter, ESC)
# - Responsividade (1920x1080)
# - Console sem erros
# - Todas as páginas funcionam
```

### 5. Push e Pull Request

```bash
git push origin feature/minha-feature
```

Abra um Pull Request no GitHub com:
- Título descritivo
- Descrição detalhada das mudanças
- Screenshots/GIFs se aplicável
- Referência a issues relacionadas

## 🎯 Áreas de Contribuição

### Frontend
- Melhorias de UI/UX
- Novas páginas
- Animações
- Acessibilidade

### Funcionalidades
- Novos controles IoT
- Integrações com APIs
- Novos serviços

### Documentação
- Tutoriais
- Exemplos de uso
- Tradução
- Diagramas

### Testes
- Testes unitários
- Testes de integração
- Testes de navegação

## 📝 Checklist do Pull Request

- [ ] Código testado localmente
- [ ] Documentação atualizada
- [ ] Commits com mensagens descritivas
- [ ] Sem conflitos com a branch main
- [ ] Screenshots/GIFs adicionados (se aplicável)
- [ ] Console sem erros ou warnings

## 🐛 Reportar Bugs

Use as [GitHub Issues](https://github.com/seu-usuario/hotel-tv-system/issues) incluindo:

- **Título claro:** "Bug: X não funciona em Y"
- **Descrição detalhada:**
  - Passos para reproduzir
  - Comportamento esperado
  - Comportamento atual
  - Screenshots/GIFs
  - Versão do navegador/TV
  - Console logs (se aplicável)

## 💡 Sugerir Features

Abra uma Issue com a tag `enhancement`:

- Descrição clara da funcionalidade
- Caso de uso
- Benefícios
- Mockups/wireframes (se possível)

## 📞 Dúvidas

- Abra uma Issue com a tag `question`
- Entre em contato via email

## 🎉 Obrigado!

Toda contribuição é bem-vinda, seja código, documentação, design ou feedback!