# 🏗️ Arquitetura do Sistema - Hotel TV

## 📋 Visão Geral

Sistema de interface de TV para hotéis com navegação por controle remoto, controle IoT e gerenciamento de hóspedes.

```
┌─────────────────────────────────────────────────────────┐
│                    SMART TV (1920x1080)                 │
│                                                          │
│  ┌────────────────────────────────────────────────────┐ │
│  │           HOTEL TV INTERFACE (index.html)          │ │
│  │                                                    │ │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐          │ │
│  │  │ Checkout │ │ Billing  │ │ Controls │          │ │
│  │  └──────────┘ └──────────┘ └──────────┘          │ │
│  │  ┌──────────┐ ┌──────────┐                       │ │
│  │  │ Services │ │   Info   │                       │ │
│  │  └──────────┘ └──────────┘                       │ │
│  │                                                    │ │
│  │  ┌────────────────────────────────────────┐       │ │
│  │  │    Streaming Apps (Netflix, etc)       │       │ │
│  │  └────────────────────────────────────────┘       │ │
│  └────────────────────────────────────────────────────┘ │
│                                                          │
│            TV Remote Navigation Library                 │
└─────────────────────────────────────────────────────────┘
                            │
                            │ User Interaction
                            ▼
                  ┌──────────────────┐
                  │  Remote Control   │
                  │   (Arrows, OK)    │
                  └──────────────────┘
```

---

## 📁 Estrutura de Arquivos

```
hotel-tv-system/
│
├── 📄 index.html                 # Página principal (Home)
├── 📄 info.html                  # Informações do hotel
├── 📄 checkout.html              # Processo de checkout
├── 📄 billing.html               # Fatura detalhada
├── 📄 services.html              # Serviços do hotel
├── 📄 iot-control.html           # Controle IoT (Luz e Cortina)
│
├── 📜 tv-remote.js               # Biblioteca de navegação
│
├── 📚 docs/
│   ├── README.md                 # Documentação principal
│   ├── ARCHITECTURE.md           # Este arquivo
│   └── FLUXO-VERIFICACAO.md     # Checklist de testes
│
├── 🎨 assets/                    # (Opcional - para futuras melhorias)
│   ├── images/
│   └── icons/
│
├── .gitignore                    # Arquivos ignorados pelo Git
└── LICENSE                       # Licença MIT
```

---

## 🔄 Fluxo de Navegação

### Diagrama de Estados

```
┌──────────────┐
│  BOOT TV     │
└──────┬───────┘
       │
       ▼
┌──────────────────────────────────────────┐
│          HOME (index.html)               │
│  ┌────────┐ ┌────────┐ ┌──────────┐     │
│  │Checkout│ │Billing │ │ Controls │     │
│  └────────┘ └────────┘ └──────────┘     │
│  ┌────────┐ ┌────────┐                  │
│  │Services│ │  Info  │                  │
│  └────────┘ └────────┘                  │
│  ┌──────────────────────┐               │
│  │  Streaming Apps      │               │
│  └──────────────────────┘               │
└──────────────────────────────────────────┘
       │
       │ Select Button (Enter)
       ▼
┌──────────────────────────────────────────┐
│       INTERNAL PAGE (iframe)             │
│  ┌────────────────────────────────┐      │
│  │  [Voltar] ← Back Button        │      │
│  │                                 │      │
│  │  Content...                     │      │
│  │                                 │      │
│  └────────────────────────────────┘      │
└──────────────────────────────────────────┘
       │
       │ Press Back/ESC
       ▼
    [Volta para HOME]
```

---

## 🎯 Componentes Principais

### 1. **TV Remote Library (tv-remote.js)**

**Responsabilidades:**
- Gerenciamento de foco entre elementos
- Mapeamento de teclas do controle remoto
- Sistema de eventos customizados
- Navegação direcional

**Classes Principais:**
```javascript
├── KeyMapper          // Mapeia teclas para ações
├── FocusManager       // Gerencia elementos focáveis
└── TVRemote           // API pública (singleton)
```

**Eventos Disparados:**
```javascript
- tv:init              // Sistema inicializado
- tv:focus             // Elemento ganhou foco
- tv:blur              // Elemento perdeu foco
- tv:select            // Enter/OK pressionado
- tv:back              // Back/ESC pressionado
- tv:keydown           // Qualquer tecla pressionada
```

---

### 2. **Index.html (Home)**

**Componentes:**
```html
├── Header (Boas-vindas + Nome + Quarto)
├── Banner Hero (Imagem de fundo)
├── Navigation Menu (5 botões principais)
│   ├── Checkout
│   ├── Billing
│   ├── Controls (IoT)
│   ├── Services
│   └── Info
├── Streaming Apps (4 apps)
│   ├── Netflix
│   ├── Spotify
│   ├── YouTube
│   └── Apple TV
└── Iframe Container (para páginas internas)
```

**Ciclo de Vida:**
```javascript
1. DOMContentLoaded
2. initTVRemote()           // Inicializa navegação
3. Foca primeiro elemento    // Checkout (índice 0)
4. Aguarda interação do usuário

Event: tv:select
5. openIframe(url)           // Abre página interna
6. tvRemote.destroy()        // Desativa navegação da home

Event: tv:back (do iframe)
7. closeIframe()             // Fecha iframe
8. initTVRemote()            // Reinicializa navegação
```

---

### 3. **Páginas Internas**

#### 3.1 Info (info.html)
- Horários do hotel
- Wi-Fi e senha
- Facilidades
- Ramais de contato
- Emergência

#### 3.2 Checkout (checkout.html)
- Informações da estadia
- Passos do checkout (4 etapas)
- Contato com recepção

#### 3.3 Billing (billing.html)
- Dados do hóspede
- Tabela de cobranças detalhada
- Resumo financeiro
- Forma de pagamento

#### 3.4 Services (services.html)
- Grid de 6 serviços principais
- Acesso rápido (4 botões)
- Ramais de cada serviço

#### 3.5 IoT Control (iot-control.html)
- Controle de Iluminação
  - Liga/Desliga
  - Slider de intensidade
  - Presets rápidos
- Controle de Cortina
  - Abrir/Fechar/Parar
  - Slider de posição
  - Presets rápidos

---

## 🔌 Integração de Sistemas

### Diagrama de Integração

```
┌────────────────────────┐
│   Smart TV Interface   │
│    (hotel-tv-system)   │
└───────────┬────────────┘
            │
            │ HTTP/WebSocket/MQTT
            ▼
┌────────────────────────┐
│    Backend Server      │
│  ┌──────────────────┐  │
│  │  API Gateway     │  │
│  └──────────────────┘  │
│  ┌──────────────────┐  │
│  │  Auth Service    │  │
│  └──────────────────┘  │
│  ┌──────────────────┐  │
│  │  Room Service    │  │
│  └──────────────────┘  │
│  ┌──────────────────┐  │
│  │  IoT Service     │  │
│  └──────────────────┘  │
│  ┌──────────────────┐  │
│  │  Billing Service │  │
│  └──────────────────┘  │
└───────────┬────────────┘
            │
            ▼
┌────────────────────────┐
│    Data Layer          │
│  ┌──────────────────┐  │
│  │  Database (SQL)  │  │
│  └──────────────────┘  │
│  ┌──────────────────┐  │
│  │  Cache (Redis)   │  │
│  └──────────────────┘  │
└────────────────────────┘
            │
            ▼
┌────────────────────────┐
│    IoT Devices         │
│  ┌──────────────────┐  │
│  │  Smart Lights    │  │
│  └──────────────────┘  │
│  ┌──────────────────┐  │
│  │  Smart Curtains  │  │
│  └──────────────────┘  │
│  ┌──────────────────┐  │
│  │  Smart AC        │  │
│  └──────────────────┘  │
└────────────────────────┘
```

---

## 🛠️ Stack Tecnológico

### Frontend
- **HTML5** - Estrutura semântica
- **CSS3** - Estilos e animações
  - Gradientes
  - Backdrop blur
  - Transitions
  - Grid Layout
- **JavaScript (ES5/ES6)** - Lógica e interatividade
  - Vanilla JS (sem frameworks)
  - CustomEvents API
  - Singleton Pattern
- **Bootstrap 4** - Grid system
- **Font Awesome 5** - Ícones

### Biblioteca Customizada
- **tv-remote.js** - Navegação por controle remoto
  - Event-driven architecture
  - Padrão Observer
  - Singleton Pattern

---

## 📊 Dados do Sistema

### Dados do Hóspede (Exemplo)
```json
{
  "guest": {
    "name": "João Silva",
    "room": "512",
    "checkIn": "2026-01-10",
    "checkOut": "2026-01-14",
    "nights": 4
  },
  "billing": {
    "accommodation": 1400.00,
    "food": 215.50,
    "services": 65.00,
    "taxes": 168.05,
    "total": 1848.55
  },
  "preferences": {
    "language": "pt-BR",
    "temperature": 22,
    "lightIntensity": 50,
    "curtainPosition": 0
  }
}
```

### Comandos IoT (Exemplo)
```json
{
  "device": "light",
  "room": "512",
  "command": "set",
  "params": {
    "on": true,
    "intensity": 75
  },
  "timestamp": "2026-01-14T10:30:00Z"
}
```

---

## 🔐 Considerações de Segurança

### Autenticação
- Room-based authentication
- Token JWT por sessão
- Timeout automático (24h)

### Autorização
- Hóspede só acessa seu próprio quarto
- Comandos IoT validados no backend
- Rate limiting nas APIs

### Comunicação
- HTTPS para todas as requisições
- WebSocket seguro (WSS)
- MQTT com TLS

---

## 📈 Escalabilidade

### Horizontal Scaling
```
┌─────────────┐
│  Load       │
│  Balancer   │
└──────┬──────┘
       │
   ┌───┴───┐
   │       │
   ▼       ▼
┌────┐  ┌────┐  ┌────┐
│TV-1│  │TV-2│  │TV-N│
└────┘  └────┘  └────┘
   │       │       │
   └───┬───┴───┬───┘
       │       │
   ┌───▼───────▼───┐
   │  API Cluster  │
   └───────────────┘
```

### Performance
- **Static Assets:** CDN
- **API Response:** < 100ms
- **IoT Commands:** < 500ms
- **Caching:** Redis

---

## 🧪 Testes

### Teste de Navegação
```javascript
describe('TV Remote Navigation', () => {
  test('Navega entre botões com setas');
  test('Seleciona elemento com Enter');
  test('Volta com Back/ESC');
  test('Navegação circular (wrap around)');
});
```

### Teste de Integração IoT
```javascript
describe('IoT Integration', () => {
  test('Liga/desliga luz');
  test('Ajusta intensidade da luz');
  test('Abre/fecha cortina');
  test('Ajusta posição da cortina');
});
```

### Teste de UI
- Responsividade (1920x1080)
- Contraste de cores
- Animações suaves
- Carregamento rápido

---

## 🚀 Deploy

### Ambientes

**Development:**
```bash
python3 -m http.server 8080
```

**Staging:**
```bash
nginx + PM2 + Node.js
```

**Production:**
```bash
CDN (Cloudflare/AWS CloudFront)
+ Load Balancer
+ Auto-scaling
```

### Pipeline CI/CD
```
┌──────────┐    ┌──────────┐    ┌──────────┐
│   Git    │───▶│  Build   │───▶│  Deploy  │
│  Commit  │    │  & Test  │    │  to TV   │
└──────────┘    └──────────┘    └──────────┘
```

---

## 📱 Compatibilidade

### Plataformas Testadas
- ✅ LG webOS 4.0+
- ✅ Samsung Tizen 5.0+
- ✅ Android TV 9.0+
- ✅ Fire TV
- ✅ Chrome/Edge (Desktop - para desenvolvimento)

### Navegadores
- Chrome 90+
- Edge 90+
- Firefox 88+
- Safari 14+

---

## 🔮 Roadmap Futuro

### Fase 2 (Q2 2026)
- [ ] Suporte a múltiplos idiomas (EN, ES)
- [ ] Controle de temperatura (AC)
- [ ] Integração com Alexa/Google Assistant
- [ ] Analytics de uso

### Fase 3 (Q3 2026)
- [ ] Recomendações personalizadas
- [ ] Chat com concierge
- [ ] Room service com fotos
- [ ] Pagamento in-app

### Fase 4 (Q4 2026)
- [ ] AI para preferências automáticas
- [ ] Integração com PMS (Oracle Opera)
- [ ] Mobile app companion
- [ ] Gamificação (pontos de fidelidade)

---

## 📞 Suporte

**Documentação:** `/docs/README.md`  
**Issues:** GitHub Issues  
**Email:** support@hotel-tv-system.com

---

**Versão:** 1.0.0  
**Última Atualização:** Janeiro 2026  
**Licença:** MIT